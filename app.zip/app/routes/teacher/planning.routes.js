module.exports = app => {
    const plannigs = require('../../controllers/teacher/plannings/plannings.controller.js');
    const router = require("express").Router();
    const auth = require("../../middleware/auth.js");

    router.get('/', auth , plannigs.getAllPlanning);
    router.get('/getIdPlanning/:id', auth , plannigs.getIdPlanning);
    router.get('/getIdSubObjective/:id', auth, plannigs.getIdSubObjective);
    router.get('/getIdAttitude/:id', auth, plannigs.getIdAttitude);
    router.get('/getIdSkill/:id', auth, plannigs.getIdSkill);
    router.get('/getIdObjective/:id', auth, plannigs.getIdObjective);
    router.get('/getSelectUnits', auth, plannigs.getSelectUnits);
    router.get('/getSelectAxis', auth, plannigs.getSelectAxis);
    router.post('/addPlaning', auth , plannigs.addPlaning);
    router.post('/addPlanningUnit', auth , plannigs.addPlanningUnit);
    router.post('/addPlanningAxiObjective', auth , plannigs.addPlanningAxiObjective);
    router.post('/addPlanningUnitObjective', auth , plannigs.addPlanningUnitObjective);
    router.post('/addPlanningSubObjective', auth , plannigs.addPlanningSubObjective);
    router.post('/addPlanningUnitSkill', auth , plannigs.addPlanningUnitSkill);
    router.post('/addPlanningUnitAttitude', auth , plannigs.addPlanningUnitAttitude);
    router.post('/addPlanningObjectiveIndicator', auth , plannigs.addPlanningObjectiveIndicator);
    app.use('/api/plannings', router);
};